package com.example.flashlight;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashOn = false;
//    Boolean btnclieckedtrue= false;
//    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
//    private boolean isRecording = false;
//    private AudioRecord audioRecord;
//    private Thread recordingThread;
//    private int bufferSize = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
//    ;
//    private static final double THRESHOLD = 0.5; // Adjust the threshold as per your requirement
//    int sampleRate = 44100; // Sample rate in Hz (standard for most devices)
//    int channelConfig = AudioFormat.CHANNEL_IN_MONO; // Mono channel
//    int audioFormat = AudioFormat.ENCODING_PCM_16BIT; // 16-bit PCM encoding
//    short[] audioData = new short[bufferSize / 2]; // Divide by 2 as each sample is 16 bits (2 bytes)
//    double sumOfSquares = 0.0;
//    private CameraManager cameraManager;
//    private String cameraId;
//    private boolean isFlashOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = (Button) findViewById(R.id.mainbtn1);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        try {
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFlashlight();
            }
        });
//        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
//        try {
//            cameraId = cameraManager.getCameraIdList()[0];
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
//
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
//            return;
//        }
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                if(btnclieckedtrue==true){
////                    btnclieckedtrue=false;
////                }
////                if(btnclieckedtrue==false){
////                    btnclieckedtrue=true;
////                }
////
////                if(btnclieckedtrue){
////                    if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
////                        // TODO: Consider calling
////                        //    ActivityCompat#requestPermissions
////                        // here to request the missing permissions, and then overriding
////                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
////                        //                                          int[] grantResults)
////                        // to handle the case where the user grants the permission. See the documentation
////                        // for ActivityCompat#requestPermissions for more details.
////                        return;
////                    }
////                    audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);
////
////                    startRecording();
////                }
////
////            }
////        });
//
//
//
//
    }

    private void toggleFlashlight() {
        if (isFlashAvailable()) {
            isFlashOn = !isFlashOn;
            try {
                cameraManager.setTorchMode(cameraId, isFlashOn);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isFlashAvailable() {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
    }

//    private void startRecording() {
//        isRecording = true;
//        audioRecord.startRecording();
//
//        recordingThread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                processAudio();
//            }
//        });
//        recordingThread.start();
//    }
//
//
//    private void stopRecording() {
//        isRecording = false;
//        try {
//            recordingThread.join();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        audioRecord.stop();
//        audioRecord.release();
//    }
//
//
//    private void processAudio() {
//        short[] audioData = new short[bufferSize / 2];
//        while (isRecording) {
//            int bytesRead = audioRecord.read(audioData, 0, audioData.length);
//            double sumOfSquares = 0.0;
//            for (int i = 0; i < bytesRead; i++) {
//                double sample = audioData[i] / 32768.0;
//                sumOfSquares += sample * sample;
//            }
//            if (bytesRead > 0) {
//                double rms = Math.sqrt(sumOfSquares / bytesRead);
//                if (rms > THRESHOLD && !isFlashOn) {
//                    toggleFlashlight(true);
//                } else if (rms <= THRESHOLD && isFlashOn) {
//                    toggleFlashlight(false);
//                }
//            }
//        }
//    }
//    private void toggleFlashlight(boolean enable) {
//        try {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                cameraManager.setTorchMode(cameraId, enable);
//            }
//            isFlashOn = enable;
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
//    }
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        stopRecording();
//    }
}